package com.pixelmondosguri.launcher;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import android.view.View;
public class MainActivity extends AppCompatActivity {
    @Override protected void onCreate(Bundle b){
        super.onCreate(b);
        setContentView(R.layout.activity_main);
    }
}
